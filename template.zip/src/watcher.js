/**
 * 文件监听模块
 * 
 * 在开发模式下监听文件变化并自动重新构建
 */

const chokidar = require('chokidar');
const path = require('path');

/**
 * 监听文件变化
 * @param {Object} config - 配置对象
 * @param {Function} callback - 文件变化时的回调函数
 */
function watchFiles(config, callback) {
  const watchPaths = [
    config.paths.templateDir,
    config.paths.assetsDir,
    './config.js'
  ].filter(p => p); // 过滤掉空路径

  const watcher = chokidar.watch(watchPaths, {
    persistent: true,
    ignoreInitial: true,
    awaitWriteFinish: {
      stabilityThreshold: 300,
      pollInterval: 100
    }
  });

  // 防抖处理
  let timeout;
  const debouncedCallback = () => {
    clearTimeout(timeout);
    timeout = setTimeout(() => {
      callback();
    }, 500);
  };

  watcher
    .on('change', debouncedCallback)
    .on('add', debouncedCallback)
    .on('unlink', debouncedCallback)
    .on('error', error => {
      console.error('文件监听错误:', error);
    });

  return watcher;
}

module.exports = {
  watchFiles
};

